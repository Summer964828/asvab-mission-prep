# ASVAB Mission Prep — Offline PWA

## Install on Android
1. Put this folder on a web host that supports HTTPS (GitHub Pages is a free option).
2. Open the HTTPS address in Chrome on your Android phone.
3. Let the page load completely once while online.
4. Chrome menu (⋮) -> "Install app" or "Add to Home screen".
5. Open "ASVAB Prep" from your home screen. The app's study content works offline.

The service worker caches the app so the study features continue working without internet.

## Important
The recruit-training video links stream from YouTube/Marines.com and therefore need internet. They are not copied into the app.

The practice questions are original and do not reproduce copyrighted text/questions from ASVAB for Dummies.
